/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.SharedPreferences$OnSharedPreferenceChangeListener
 *  android.net.Uri
 *  android.os.Bundle
 *  android.preference.CheckBoxPreference
 *  android.preference.Preference
 *  android.preference.Preference$OnPreferenceClickListener
 *  android.preference.PreferenceActivity
 *  android.preference.PreferenceManager
 *  android.preference.PreferenceScreen
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.themrbigfoot.wificracker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.widget.Toast;

public class SettingsClass
extends PreferenceActivity
implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int PICK_FILE_RESULT_CODE = 765;
    String contactUs = "contact_us";
    SharedPreferences.Editor editor;
    String featureRequest = "featureRequest";
    String filePath = "filePath";
    Preference filePathPref;
    String helpWebsite = "helpWebsite";
    SharedPreferences sharedPreferences;
    String spFilePath;
    String sp_contactUs;
    String sp_helpWebsite;
    String sp_use_darkTheme;
    String sp_use_hex;
    String sp_use_notification;
    String useDefaultFile = "use_default_wordlist";
    CheckBoxPreference useDefaultPreference;
    String use_hex = "password_hex";
    String use_notification = "use_notification";

    protected void onActivityResult(int n, int n2, Intent intent) {
        intent.getAction();
        if (n == 765) {
            this.spFilePath = intent.getData().getPath();
            this.editor.putString(this.filePath, this.spFilePath);
            this.editor.commit();
            this.editor.apply();
            Preference preference = this.filePathPref;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("User defined location: ");
            stringBuilder.append(this.spFilePath);
            preference.setSummary((CharSequence)stringBuilder.toString());
            this.editor.putBoolean(this.useDefaultFile, false);
            this.editor.commit();
            this.editor.apply();
            this.useDefaultPreference.setSummary((CharSequence)"Not using default wordlist.");
            this.useDefaultPreference.setChecked(false);
            Toast.makeText((Context)this.getApplicationContext(), (CharSequence)"Loaded user defined file. ", (int)0).show();
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)this.getApplicationContext());
        this.addPreferencesFromResource(2131755008);
        this.editor = this.getPreferences(0).edit();
        this.filePathPref = this.findPreference((CharSequence)this.filePath);
        String string2 = this.sharedPreferences.getString(this.filePath, "");
        if (string2 != "") {
            Preference preference = this.filePathPref;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("User defined file at location: ");
            stringBuilder.append(string2);
            preference.setSummary((CharSequence)stringBuilder.toString());
            this.useDefaultPreference.setChecked(false);
        }
        this.filePathPref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent("android.intent.action.GET_CONTENT");
                intent.setType("text/plain");
                SettingsClass.this.startActivityForResult(intent, 765);
                return true;
            }
        });
        this.useDefaultPreference = (CheckBoxPreference)this.findPreference((CharSequence)this.useDefaultFile);
        this.useDefaultPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                if (preference.isEnabled()) {
                    SettingsClass.this.useDefaultPreference.setChecked(true);
                    SettingsClass.this.editor.putBoolean(SettingsClass.this.useDefaultFile, true);
                    SettingsClass.this.editor.commit();
                    SettingsClass.this.editor.apply();
                    preference.setSummary((CharSequence)"Using default wordlist.");
                    SettingsClass.this.editor.putString(SettingsClass.this.filePath, "");
                    SettingsClass.this.editor.commit();
                    SettingsClass.this.editor.apply();
                }
                return false;
            }
        });
        this.findPreference((CharSequence)this.helpWebsite).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse((String)"https://badappsdevelopment-wificracker.weebly.com/"));
                SettingsClass.this.startActivity(intent);
                return false;
            }
        });
        ((CheckBoxPreference)this.findPreference((CharSequence)this.use_hex)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                if (preference.isEnabled()) {
                    SettingsClass.this.editor.putBoolean(SettingsClass.this.use_hex, true);
                    SettingsClass.this.editor.commit();
                    SettingsClass.this.editor.apply();
                    preference.setSummary((CharSequence)"Wifi Cracker will treat your word very special requires more work. Slower Process.");
                    return false;
                }
                SettingsClass.this.editor.putBoolean(SettingsClass.this.use_hex, false);
                SettingsClass.this.editor.commit();
                SettingsClass.this.editor.apply();
                preference.setSummary((CharSequence)"Wifi Cracker will do nothing special with your wordlist. This setting makes the app run smoother.");
                return false;
            }
        });
        ((CheckBoxPreference)this.findPreference((CharSequence)this.use_notification)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                if (preference.isEnabled()) {
                    preference.setSummary((CharSequence)"Wifi Cracker will send you a notification with the progress of the dictionary attack and run the process in the background.");
                } else {
                    preference.setSummary((CharSequence)"Wifi Cracker will run dictionary attack in the background and show a progress bar to show progress.");
                }
                return false;
            }
        });
        this.findPreference((CharSequence)this.contactUs).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent("android.intent.action.SENDTO", Uri.fromParts((String)"mailto", (String)"trevatk55@gmail.com", null));
                intent.putExtra("android.intent.extra.SUBJECT", "Contact Us");
                intent.putExtra("android.intent.extra.TEXT", "");
                SettingsClass.this.startActivity(Intent.createChooser((Intent)intent, (CharSequence)"Send email..."));
                return false;
            }
        });
        this.findPreference((CharSequence)this.featureRequest).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener(){

            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent("android.intent.action.SENDTO", Uri.fromParts((String)"mailto", (String)"trevatk55@gmail.com", null));
                intent.putExtra("android.intent.extra.SUBJECT", "Feature Request");
                intent.putExtra("android.intent.extra.TEXT", "");
                SettingsClass.this.startActivity(Intent.createChooser((Intent)intent, (CharSequence)"Send email..."));
                return true;
            }
        });
    }

    protected void onPause() {
        super.onPause();
        this.getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener((SharedPreferences.OnSharedPreferenceChangeListener)this);
    }

    protected void onResume() {
        super.onResume();
        this.getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener((SharedPreferences.OnSharedPreferenceChangeListener)this);
    }

    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String string2) {
        Preference preference = this.findPreference((CharSequence)string2);
        if (string2.equals((Object)"filePath")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("File location: ");
            stringBuilder.append(this.spFilePath);
            preference.setSummary((CharSequence)stringBuilder.toString());
        }
    }

}

